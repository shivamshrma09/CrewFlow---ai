VIDEO DEMO - https://vimeo.com/1203566805?share=copy&fl=sv&fe=ci
GITHUB - https://github.com/shivamshrma09/CrewFlow---ai